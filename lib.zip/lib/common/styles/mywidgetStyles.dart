import 'package:flutter/material.dart';

TextStyle labelHintFontStyle = TextStyle(
  color: Colors.black87,
  fontSize: 14.5,
  fontWeight: FontWeight.w600,
  // fontFamily: pCommonRegularFont,
);
// TextStyle textStyleCustom(color, fontsize, fontweight) => TextStyle(
//       color: color,
//       fontSize: fontsize,
//       fontWeight: fontweight,
//       // fontFamily: pCommonRegularFont,
//     );
